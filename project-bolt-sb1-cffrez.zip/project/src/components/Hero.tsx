import React from 'react';
import { Brain } from 'lucide-react';

export default function Hero() {
  return (
    <div className="bg-gradient-to-b from-[#003049] to-[#023e5f] text-white py-20">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Transform Your Data Into Insights
            </h1>
            <p className="text-xl mb-8">
              Advanced analytics platform combining Power BI integration with 
              machine learning capabilities for comprehensive data analysis.
            </p>
            <button className="bg-white text-[#003049] px-8 py-3 rounded-lg font-semibold 
              hover:bg-gray-100 transition duration-300">
              Get Started
            </button>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80"
              alt="Data Analytics Dashboard"
              className="rounded-lg shadow-2xl max-w-md w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
}