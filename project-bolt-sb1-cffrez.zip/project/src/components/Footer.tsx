import React from 'react';
import { BarChart2 } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#003049] text-white py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-6 md:mb-0">
            <BarChart2 className="h-8 w-8 mr-2" />
            <span className="text-2xl font-bold">YOUNES</span>
          </div>
          <div className="flex space-x-6">
            <a href="#features" className="hover:text-gray-300">Features</a>
            <a href="#analytics" className="hover:text-gray-300">Analytics</a>
            <a href="#contact" className="hover:text-gray-300">Contact</a>
          </div>
        </div>
        <div className="mt-8 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} YOUNES. All rights reserved.
        </div>
      </div>
    </footer>
  );
}