import React from 'react';
import { Menu, X, BarChart2, Database, Brain, Mail, Phone, MapPin } from 'lucide-react';

export default function Header() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <header className="bg-[#003049] text-white">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <BarChart2 className="h-8 w-8 mr-2" />
            <span className="text-2xl font-bold">YOUNES</span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#features" className="hover:text-gray-300">Features</a>
            <a href="#analytics" className="hover:text-gray-300">Analytics</a>
            <a href="#contact" className="hover:text-gray-300">Contact</a>
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden">
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <a href="#features" className="block hover:text-gray-300">Features</a>
            <a href="#analytics" className="block hover:text-gray-300">Analytics</a>
            <a href="#contact" className="block hover:text-gray-300">Contact</a>
          </div>
        )}
      </nav>
    </header>
  );
}