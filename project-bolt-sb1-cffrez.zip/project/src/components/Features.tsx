import React from 'react';
import { BarChart2, Database, Brain, Share2 } from 'lucide-react';

const features = [
  {
    icon: <BarChart2 className="h-8 w-8" />,
    title: "Power BI Integration",
    description: "Seamlessly connect and visualize your Power BI reports and dashboards"
  },
  {
    icon: <Database className="h-8 w-8" />,
    title: "Data Management",
    description: "Efficient data storage and processing with advanced querying capabilities"
  },
  {
    icon: <Brain className="h-8 w-8" />,
    title: "ML Models",
    description: "Deploy and manage machine learning models with ease"
  },
  {
    icon: <Share2 className="h-8 w-8" />,
    title: "Collaboration",
    description: "Real-time collaboration tools for team analysis and insights sharing"
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12 text-[#003049]">
          Platform Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300">
              <div className="text-[#003049] mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}